<?php
$query=mysqli_connect("localhost","root","","haiwan");
if (mysqli_connect_errno()){
	echo "gagal:".mysqli_connect_error();
}
?>