<?php
include 'config.php';
$id_binatang=$_POST['id_binatang'];
$nama=$_POST['nama'];
$jenis=$_POST['jenis'];

echo "<br>";

$query= "INSERT INTO maklumat values
('$id_binatang','$nama','$jenis')";
$result=mysqli_query($query);

if($result)
{
	include("papar.php");
}
else{
	include ("index.php");
}
?>