<?php
include 'config.php';
?>

<html>
<head>
<title>BINATANG</title></head>

<body>
<h2>JOM KENAL BINATANG</h2>
<form action="insert.php" method="post">
<fieldset>
<p>ID BINATANG :
<input type="text" size="40" name="id_binatang" placeholder="MASUKKAN ID BINATANG"></p>
<p>NAMA BINATANG :
<input type="text" size="40" name="nama" placeholder="MASUKKAN NAMA BINATANG"></p>
<p>JENIS :
<select name="jenis">
<option> HERBIVOR </option>
<option> KARNIVOR </option>
<option> OMNIVOR </option>
</select></p>

<input type="SUBMIT" name="submit">
<input type="RESET" name="reset">


</fieldset>

</body>

</html>